﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    public class Semi:Vehicle
    {
    public Semi(int capacity) : base(10) { }
    }

